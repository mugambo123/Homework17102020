public class Twelve {
    public static void main(String[] args) {
        // compute the specified expressions
        System.out.println((25.5*3.5 - 3.5*3.5)/(40.5-4.5));
    }
}

