public class Eleven {
    public static void main(String[] args) {
        // writing java program to display the pattern
        System.out.println(" J  a  v  v a");
        System.out.println(" J a a  v v a a");
        System.out.println("J J aaaaa V V aaaaa");
        System.out.println(" JJ a  a V a   a");
    }
}

