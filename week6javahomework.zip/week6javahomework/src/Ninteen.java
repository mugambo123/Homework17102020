public class Ninteen {
    public static void main(String[] args) {
        String capitalCase = "The QUICK BROWN FOX JUMPS OVER THE LAZY DOG.";
        System.out.println(capitalCase.toLowerCase()); // converting capital case into lowercase.
    }
}

