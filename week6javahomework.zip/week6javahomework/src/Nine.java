public class Nine {
    public static void main(String[] args) {
        String input1 = "I REALLY LOVE IDEA OF LIFELONG LEARNING.";
        String input2 = "i really want to become world class automation qa engineer.";
        String input3 = "diE aNotheR dAy";
        System.out.println(input1.toLowerCase());// Convert Uppercase into Lowercase
        System.out.println();
        System.out.println(input2.toUpperCase());// Convert Lowercase into Uppercase
        System.out.println();
        System.out.println(input3.toUpperCase());// Convert Any Case into Uppercase



    }
}
